package com.example.assignment.tennis;

public class GameScore {
	private Tennis tennis;
	public GameScore() {
		this.tennis = new Tennis();
	}
	public void game() {
		tennis.firstPlayerScore();
		//tennis.firstPlayerScore();
		tennis.secondPlayerScore();
		//tennis.firstPlayerScore();
		//tennis.secondPlayerScore();
		//tennis.secondPlayerScore();
		
		System.out.println(tennis.getScore());
	}

	public static void main(String[] args) {
		GameScore gameScore = new GameScore();
		gameScore.game();
	}

}
