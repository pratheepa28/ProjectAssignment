package com.example.assignment.tictactoe;

public class TicTacToe {
	private char[][] board = new char[3][3];

	public TicTacToe() {
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				board[i][j]=' ';
			}
		}
	}
	
	public void play(int row,int col,char player) {
		if(row<0 || row>=3 || col<0 || col>=3) {
			throw new IllegalArgumentException("Invalid row or column");
		}
		
		if(board[row][col] != ' ') {
			throw new IllegalArgumentException("Cell is occupied");
		}
		board[row][col]= player;
	}
	
	public char winner() {
		for(int i=0;i<3;i++) {
			if(board[i][0]== board[i][1] && board[i][1]== board[i][2] && board[i][0]!=' ') {
				return board[i][0];
			}
		}
		
		for(int i=0;i<3;i++) {
			if(board[0][i]== board[i][1] && board[1][i]== board[2][i] && board[0][i]!=' ') {
				return board[0][i];
			}
		}
		
		for(int i=0;i<3;i++) {
			if(board[0][0]== board[1][1] && board[1][1]== board[2][2] && board[0][0]!=' ') {
				return board[0][0];
			}
		}
		
		for(int i=0;i<3;i++) {
			if(board[0][2]== board[1][1] && board[1][1]== board[2][0] && board[0][2]!=' ') {
				return board[0][2];
			}
		}
		
		return ' ';
	}
	
	public boolean drawMatch() {
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				board[i][j]=' ';
			}
		}
		return true;
	}
}
