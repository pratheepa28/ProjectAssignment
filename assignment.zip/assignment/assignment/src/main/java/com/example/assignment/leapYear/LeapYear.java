package com.example.assignment.leapYear;

import java.util.Scanner;

public class LeapYear {
	static int year;

	public static void main(String[] args) {
		try {
			Scanner s = new Scanner(System.in);
			System.out.println("Enter the Year :");
			int year = s.nextInt();
			s.nextLine();
			checkLeapYear(year);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static boolean checkLeapYear(int year) {
		if(year%400 == 0) {
			System.out.println(year +" is a LeapYear");
			return true;
		}else if( year%100 == 0 && year%400 !=0) {
			System.out.println(year +" is not a LeapYear");
			return false;
		}else if( year%4 == 0 && year%100 !=0) {
			System.out.println(year +" is a LeapYear");
			return true;
		}else if( year%4 != 0) {
			System.out.println(year +" is not a LeapYear");
			return false;
		}
		return false;
		
	}

}
